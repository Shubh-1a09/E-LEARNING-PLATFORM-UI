// Handle Course Search
function searchCourses() {
    let input = document.getElementById('searchBar').value.toLowerCase();
    let courses = document.querySelectorAll('.course-card');
    
    courses.forEach(course => {
        let courseTitle = course.querySelector('h3').innerText.toLowerCase();
        if (courseTitle.includes(input)) {
            course.style.display = "block";
        } else {
            course.style.display = "none";
        }
    });
}

// Handle Category Filtering
document.getElementById('categoryFilter').addEventListener('change', function() {
    let selectedCategory = this.value;
    let courses = document.querySelectorAll('.course-card');
    
    courses.forEach(course => {
        if (selectedCategory === 'all' || course.dataset.category === selectedCategory) {
            course.style.display = "block";
        } else {
            course.style.display = "none";
        }
    });
});

// Progress Bar Animation
function animateProgressBar() {
    const progressBars = document.querySelectorAll('.progress-bar div');
    progressBars.forEach(bar => {
        let progress = bar.style.width;
        bar.style.transition = 'width 1s ease-in-out';
        bar.style.width = progress;
    });
}

// Modal Popup for Course Details
const courseLinks = document.querySelectorAll('.view-course');
const modal = document.createElement('div');
modal.classList.add('modal');
document.body.appendChild(modal);

courseLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const courseTitle = link.previousElementSibling.innerText;
        modal.innerHTML = `
            <div class="modal-content">
                <h2>${courseTitle}</h2>
                <p>Course details go here...</p>
                <button class="close-modal">Close</button>
            </div>
        `;
        modal.style.display = 'block';

        const closeModalButton = document.querySelector('.close-modal');
        closeModalButton.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    });
});

// Dark Mode Toggle
const darkModeToggle = document.createElement('button');
darkModeToggle.innerText = 'Toggle Dark Mode';
darkModeToggle.classList.add('dark-mode-toggle');
document.body.appendChild(darkModeToggle);

darkModeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

// Sticky Navigation
const header = document.querySelector('header');
const nav = document.querySelector('nav');

window.onscroll = function() {
    if (window.pageYOffset > header.offsetTop) {
        nav.classList.add('sticky');
    } else {
        nav.classList.remove('sticky');
    }
};

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Tooltip for Course Cards
const courseCards = document.querySelectorAll('.course-card');
courseCards.forEach(card => {
    card.addEventListener('mouseover', () => {
        const tooltip = document.createElement('div');
        tooltip.classList.add('tooltip');
        tooltip.innerText = "Click to learn more about this course!";
        card.appendChild(tooltip);
    });

    card.addEventListener('mouseleave', () => {
        const tooltip = card.querySelector('.tooltip');
        if (tooltip) {
            tooltip.remove();
        }
    });
});

// Form validation for login and signup
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(event) {
        let username = form.querySelector('input[name="username"]').value;
        let password = form.querySelector('input[name="password"]').value;
        let email = form.querySelector('input[name="email"]');
        let errorMessage = '';

        if (username === '') {
            errorMessage = 'Username is required.';
        } else if (password === '') {
            errorMessage = 'Password is required.';
        } else if (email && email.value === '') {
            errorMessage = 'Email is required.';
        }

        if (errorMessage) {
            event.preventDefault();
            alert(errorMessage);
        }
    });
});

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    animateProgressBar();  // Trigger progress bar animation on page load
    setDarkMode(); // Check if Dark Mode was previously enabled
});

// Dark Mode Persistence (Using localStorage)
function setDarkMode() {
    const darkModeStatus = localStorage.getItem('dark-mode');
    if (darkModeStatus === 'enabled') {
        document.body.classList.add('dark-mode');
    }
}

// Save Dark Mode Preference
darkModeToggle.addEventListener('click', () => {
    const isDarkMode = document.body.classList.contains('dark-mode');
    if (isDarkMode) {
        localStorage.setItem('dark-mode', 'enabled');
    } else {
        localStorage.setItem('dark-mode', 'disabled');
    }
});
// Form validation for login and signup
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(event) {
        let username = form.querySelector('input[name="username"]').value;
        let password = form.querySelector('input[name="password"]').value;
        let email = form.querySelector('input[name="email"]');
        let confirmPassword = form.querySelector('input[name="confirmPassword"]');
        let errorMessage = '';

        if (form.id === 'loginForm') {
            if (username === '') {
                errorMessage = 'Username is required.';
            } else if (password === '') {
                errorMessage = 'Password is required.';
            }
        } else if (form.id === 'signupForm') {
            if (username === '') {
                errorMessage = 'Username is required.';
            } else if (email === '' || !validateEmail(email.value)) {
                errorMessage = 'Please enter a valid email.';
            } else if (password === '') {
                errorMessage = 'Password is required.';
            } else if (confirmPassword === '') {
                errorMessage = 'Please confirm your password.';
            } else if (password !== confirmPassword.value) {
                errorMessage = 'Passwords do not match.';
            }
        }

        if (errorMessage) {
            event.preventDefault();
            alert(errorMessage);
        }
    });
});

// Helper function to validate email format
function validateEmail(email) {
    const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return re.test(String(email).toLowerCase());
}
